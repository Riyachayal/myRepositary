
import java.sql.Connection;
import java.sql.DriverManager;

public class Hello {

	// Rule
	// 1) Recording
	// 2) Assignment
	// 3) Doubt clearing session // 99%
	
	// JDBC rule
	// 1) java p
	// 2) add jar's
	// 3) class
	// 4) driver
	// 5) Connection
	
	
	
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub	
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver Load");
	
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch137", "root", "root");
		System.out.println("Connection Done Succcccccccessssfullllllly");
		
	}

}
